﻿namespace Capitalism.Core.Interfaces.UserInterfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}