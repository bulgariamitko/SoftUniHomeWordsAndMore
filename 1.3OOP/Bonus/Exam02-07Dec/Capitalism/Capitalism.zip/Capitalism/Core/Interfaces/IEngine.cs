﻿namespace Capitalism.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}