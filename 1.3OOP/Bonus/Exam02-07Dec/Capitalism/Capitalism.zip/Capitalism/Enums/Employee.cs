﻿namespace Capitalism.Enums
{
    public enum Employee
    {
        CEO, Manager, RegularEmployee, CleaningLady, Salesmen, ChiefTelefphoneOfficer, Accountant
    }
}