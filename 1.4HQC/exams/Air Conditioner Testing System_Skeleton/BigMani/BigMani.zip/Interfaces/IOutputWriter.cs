﻿namespace BigMani.Interfaces
{
    public interface IOutputWriter
    {
        void Print(string message);
    }
}