﻿namespace BigMani.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
